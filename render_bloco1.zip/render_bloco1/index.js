// index.js bloco 1
console.log('Miguel Render Bloco 1');